package Telas;

import Classes.Cliente;
import Classes.Grupo;
import Classes.Subgrupo;
import Classes.UsuarioIDTransfer;
import Classes.Transacao;
import DAO.ClienteDAO;
import DAO.GrupoDAO;
import DAO.SubgrupoDAO;
import DAO.TransacaoDAO;
import Telas.Alterar.TelaAlterarCliente;
import Telas.Alterar.TelaAlterarGrupo;
import Telas.Alterar.TelaAlterarSubgrupo;
import Telas.Cadastrar.TelaCadastrarCliente;
import Telas.Cadastrar.TelaCadastrarGrupo;
import Telas.Cadastrar.TelaCadastrarSubgrupo;
import java.awt.Color;
import java.awt.Component;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.text.MaskFormatter;


public class TelaPrincipal extends javax.swing.JFrame
{
    private Integer idUsuario;
    
    MaskFormatter dataFormat;
        
    public TelaPrincipal()
    {
        try
        {
            dataFormat = new MaskFormatter("##/##/####");
            dataFormat.setPlaceholderCharacter('_');
            
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao aplicar máscaras");
        }
        
        this.idUsuario = UsuarioIDTransfer.getLoginID();
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
        setResizable(false);
        
        jtfValor.setForeground(Color.GRAY);
        jtfValor.setText("R$ 0000,00");
        
        atualizaTabela("cliente", jtTabelaCliente);
        atualizaTabela("grupo", jtTabelaGrupo);
        atualizaTabela("subgrupo", jtTabelaSubgrupo);
    }
    
    public void atualizaTabela(String tipoTabela, JTable tabela)
    {
        DefaultTableModel table = (DefaultTableModel) tabela.getModel();
        table.setRowCount(0);
        ClienteDAO clienteDAO = new ClienteDAO();
        GrupoDAO grupoDAO = new GrupoDAO();
        
        switch(tipoTabela)
        {
            case "cliente":
                
                ArrayList<Cliente> listaClientes = new ArrayList<>();
                listaClientes = clienteDAO.getClientes();
                for(Cliente cliente: listaClientes)
                {
                    Object[] linha ={cliente.getIdCliente(), cliente.getNome()};
                    table.addRow(linha);
                }
                break;
            
            case "grupo":
                
                ArrayList<Grupo> listaGrupos = new ArrayList<>();
                listaGrupos = grupoDAO.getGrupos();
                for(Grupo grupo: listaGrupos)
                {
                    Object[] linha ={grupo.getIdGrupo(), grupo.getNome()};
                    table.addRow(linha);
                }
                break;
            
            case "subgrupo":
                if(!jtfCadastroGrupo.getText().isBlank())
                {
                    ArrayList<Subgrupo> listaSubgrupos = new ArrayList<>();
                    listaSubgrupos = GrupoDAO.getSubgruposFromGrupo(jtfCadastroGrupo.getText());
                    for(Subgrupo subgrupo: listaSubgrupos)
                    {
                        Object[] linha ={subgrupo.getIdSubgrupo(), subgrupo.getNome()};
                        table.addRow(linha);
                    }
                }
                break;
        }
        
        for (int column = 0; column < tabela.getColumnCount(); column++)
        {
            TableColumn tableColumn = tabela.getColumnModel().getColumn(column);
            int preferredWidth = tableColumn.getMinWidth();
            int maxWidth = tableColumn.getMaxWidth();

            for (int row = 0; row < tabela.getRowCount(); row++)
            {
                TableCellRenderer cellRenderer = tabela.getCellRenderer(row, column);
                Component c = tabela.prepareRenderer(cellRenderer, row, column);
                int width = c.getPreferredSize().width + tabela.getIntercellSpacing().width;
                preferredWidth = Math.max(preferredWidth, width);

                if (preferredWidth >= maxWidth)
                {
                    preferredWidth = maxWidth;
                    break;
                }
            }
            tableColumn.setPreferredWidth( preferredWidth);
        }
    }
    
    public String getDateTimeForMYSQL()
    {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        return formattedDateTime;
    }
    
    private String formatTime(String dateTime)
    {
        String[] dateTimeParts = dateTime.split("/");
        String result = dateTimeParts[2]+"-"+dateTimeParts[1]+"-"+dateTimeParts[0];
        return result;
    }
    
    
        

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jbgTipoTransacao = new javax.swing.ButtonGroup();
        jpEspacador = new javax.swing.JPanel();
        jpCliente = new javax.swing.JPanel();
        jlCadastroCliente = new javax.swing.JLabel();
        jtfCadastroCliente = new javax.swing.JTextField();
        jspTabelaCliente = new javax.swing.JScrollPane();
        jtTabelaCliente = new javax.swing.JTable();
        jpGrupo = new javax.swing.JPanel();
        jlCadastroGrupo = new javax.swing.JLabel();
        jtfCadastroGrupo = new javax.swing.JTextField();
        jspTabelaGrupo = new javax.swing.JScrollPane();
        jtTabelaGrupo = new javax.swing.JTable();
        jpSubgrupo = new javax.swing.JPanel();
        jlCadastroSubgrupo = new javax.swing.JLabel();
        jtfCadastroSubgrupo = new javax.swing.JTextField();
        jspTabelaSubgrupo = new javax.swing.JScrollPane();
        jtTabelaSubgrupo = new javax.swing.JTable();
        jpTransacao = new javax.swing.JPanel();
        jrbEntrada = new javax.swing.JRadioButton();
        jrbSaida = new javax.swing.JRadioButton();
        jlValor = new javax.swing.JLabel();
        jlDataPagamento = new javax.swing.JLabel();
        jbCadastrar = new javax.swing.JButton();
        jffDataPagamento = new javax.swing.JFormattedTextField(dataFormat);
        jtfValor = new javax.swing.JTextField();
        jmbMenu = new javax.swing.JMenuBar();
        jmCadastrar = new javax.swing.JMenu();
        jmiCadastrarCliente = new javax.swing.JMenuItem();
        jmiCadastrarGrupo = new javax.swing.JMenuItem();
        jmiCadastrarSubgrupo = new javax.swing.JMenuItem();
        jmAlterar = new javax.swing.JMenu();
        jmiAlterarCliente = new javax.swing.JMenuItem();
        jmiAlterarGrupo = new javax.swing.JMenuItem();
        jmiAlterarSubgrupo = new javax.swing.JMenuItem();
        jmiFiller = new javax.swing.JMenu();
        jmiDelogar = new javax.swing.JMenu();
        jmiSair1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jpEspacadorLayout = new javax.swing.GroupLayout(jpEspacador);
        jpEspacador.setLayout(jpEspacadorLayout);
        jpEspacadorLayout.setHorizontalGroup(
            jpEspacadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jpEspacadorLayout.setVerticalGroup(
            jpEspacadorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 59, Short.MAX_VALUE)
        );

        jlCadastroCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlCadastroCliente.setText("Cadastro do Cliente");

        jtfCadastroCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jtTabelaCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jtTabelaCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cadastro Cliente", "Nome Cliente"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtTabelaCliente.setRowHeight(50);
        jspTabelaCliente.setViewportView(jtTabelaCliente);

        javax.swing.GroupLayout jpClienteLayout = new javax.swing.GroupLayout(jpCliente);
        jpCliente.setLayout(jpClienteLayout);
        jpClienteLayout.setHorizontalGroup(
            jpClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpClienteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jspTabelaCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 494, Short.MAX_VALUE)
                    .addGroup(jpClienteLayout.createSequentialGroup()
                        .addComponent(jlCadastroCliente)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtfCadastroCliente)
                        .addContainerGap())))
        );
        jpClienteLayout.setVerticalGroup(
            jpClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpClienteLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jpClienteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfCadastroCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlCadastroCliente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspTabelaCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jlCadastroGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlCadastroGrupo.setText("Cadastro do Grupo");

        jtfCadastroGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jtfCadastroGrupo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtfCadastroGrupoKeyReleased(evt);
            }
        });

        jtTabelaGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jtTabelaGrupo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cadastro Grupo", "Nome Grupo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtTabelaGrupo.setRowHeight(50);
        jspTabelaGrupo.setViewportView(jtTabelaGrupo);

        javax.swing.GroupLayout jpGrupoLayout = new javax.swing.GroupLayout(jpGrupo);
        jpGrupo.setLayout(jpGrupoLayout);
        jpGrupoLayout.setHorizontalGroup(
            jpGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpGrupoLayout.createSequentialGroup()
                .addGroup(jpGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpGrupoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jlCadastroGrupo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtfCadastroGrupo))
                    .addComponent(jspTabelaGrupo, javax.swing.GroupLayout.DEFAULT_SIZE, 488, Short.MAX_VALUE))
                .addContainerGap())
        );
        jpGrupoLayout.setVerticalGroup(
            jpGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpGrupoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jpGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlCadastroGrupo)
                    .addComponent(jtfCadastroGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspTabelaGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jlCadastroSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlCadastroSubgrupo.setText("Cadastro do Subgrupo");

        jtfCadastroSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jtTabelaSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jtTabelaSubgrupo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cadastro Subgrupo", "Nome Subgrupo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtTabelaSubgrupo.setRowHeight(50);
        jspTabelaSubgrupo.setViewportView(jtTabelaSubgrupo);

        javax.swing.GroupLayout jpSubgrupoLayout = new javax.swing.GroupLayout(jpSubgrupo);
        jpSubgrupo.setLayout(jpSubgrupoLayout);
        jpSubgrupoLayout.setHorizontalGroup(
            jpSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpSubgrupoLayout.createSequentialGroup()
                .addGroup(jpSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpSubgrupoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jlCadastroSubgrupo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtfCadastroSubgrupo))
                    .addComponent(jspTabelaSubgrupo))
                .addContainerGap())
        );
        jpSubgrupoLayout.setVerticalGroup(
            jpSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpSubgrupoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlCadastroSubgrupo)
                    .addComponent(jtfCadastroSubgrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspTabelaSubgrupo, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
        );

        jbgTipoTransacao.add(jrbEntrada);
        jrbEntrada.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jrbEntrada.setText("Entrada");

        jbgTipoTransacao.add(jrbSaida);
        jrbSaida.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jrbSaida.setText("Saída");

        jlValor.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlValor.setText("Valor");

        jlDataPagamento.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlDataPagamento.setText("Data Pagamento");

        jbCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbCadastrar.setText("Cadastrar");
        jbCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCadastrarActionPerformed(evt);
            }
        });

        jffDataPagamento.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jtfValor.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jtfValor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jtfValorFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jtfValorFocusLost(evt);
            }
        });

        javax.swing.GroupLayout jpTransacaoLayout = new javax.swing.GroupLayout(jpTransacao);
        jpTransacao.setLayout(jpTransacaoLayout);
        jpTransacaoLayout.setHorizontalGroup(
            jpTransacaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpTransacaoLayout.createSequentialGroup()
                .addGroup(jpTransacaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpTransacaoLayout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(jlValor)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtfValor))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpTransacaoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jrbEntrada)
                        .addGap(18, 18, 18)
                        .addComponent(jrbSaida))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpTransacaoLayout.createSequentialGroup()
                        .addGap(144, 144, 144)
                        .addComponent(jbCadastrar))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jpTransacaoLayout.createSequentialGroup()
                        .addComponent(jlDataPagamento)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jffDataPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpTransacaoLayout.setVerticalGroup(
            jpTransacaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpTransacaoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpTransacaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jrbEntrada)
                    .addComponent(jrbSaida))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpTransacaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlValor)
                    .addComponent(jtfValor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(jpTransacaoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlDataPagamento)
                    .addComponent(jffDataPagamento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jbCadastrar)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jmbMenu.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N

        jmCadastrar.setText("Cadastrar");
        jmCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jmiCadastrarCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarCliente.setText("Cliente");
        jmiCadastrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiCadastrarClienteActionPerformed(evt);
            }
        });
        jmCadastrar.add(jmiCadastrarCliente);

        jmiCadastrarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarGrupo.setText("Grupo");
        jmiCadastrarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiCadastrarGrupoActionPerformed(evt);
            }
        });
        jmCadastrar.add(jmiCadastrarGrupo);

        jmiCadastrarSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarSubgrupo.setText("SubGrupo");
        jmiCadastrarSubgrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiCadastrarSubgrupoActionPerformed(evt);
            }
        });
        jmCadastrar.add(jmiCadastrarSubgrupo);

        jmbMenu.add(jmCadastrar);

        jmAlterar.setText("Alterar");
        jmAlterar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jmiAlterarCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarCliente.setText("Cliente");
        jmiAlterarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiAlterarClienteActionPerformed(evt);
            }
        });
        jmAlterar.add(jmiAlterarCliente);

        jmiAlterarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarGrupo.setText("Grupo");
        jmiAlterarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiAlterarGrupoActionPerformed(evt);
            }
        });
        jmAlterar.add(jmiAlterarGrupo);

        jmiAlterarSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarSubgrupo.setText("SubGrupo");
        jmiAlterarSubgrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiAlterarSubgrupoActionPerformed(evt);
            }
        });
        jmAlterar.add(jmiAlterarSubgrupo);

        jmbMenu.add(jmAlterar);

        jmiFiller.setText("                        ");
        jmiFiller.setBorderPainted(false);
        jmiFiller.setContentAreaFilled(false);
        jmiFiller.setEnabled(false);
        jmiFiller.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmbMenu.add(jmiFiller);

        jmiDelogar.setText("Deslogar");
        jmiDelogar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiDelogar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jmiDelogarMouseClicked(evt);
            }
        });
        jmbMenu.add(jmiDelogar);

        jmiSair1.setText("Sair");
        jmiSair1.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiSair1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jmiSair1MouseClicked(evt);
            }
        });
        jmbMenu.add(jmiSair1);

        setJMenuBar(jmbMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jpCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jpTransacao, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpGrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpSubgrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addComponent(jpEspacador, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jpEspacador, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jpGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jpSubgrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jpTransacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jmiSair1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jmiSair1MouseClicked
        dispose();
    }//GEN-LAST:event_jmiSair1MouseClicked

    private void jmiCadastrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiCadastrarClienteActionPerformed
        TelaCadastrarCliente tela = new TelaCadastrarCliente();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiCadastrarClienteActionPerformed

    private void jmiCadastrarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiCadastrarGrupoActionPerformed
        TelaCadastrarGrupo tela = new TelaCadastrarGrupo();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiCadastrarGrupoActionPerformed

    private void jmiCadastrarSubgrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiCadastrarSubgrupoActionPerformed
        TelaCadastrarSubgrupo tela = new TelaCadastrarSubgrupo();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiCadastrarSubgrupoActionPerformed

    private void jmiAlterarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiAlterarClienteActionPerformed
        TelaAlterarCliente tela = new TelaAlterarCliente();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiAlterarClienteActionPerformed

    private void jmiAlterarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiAlterarGrupoActionPerformed
        TelaAlterarGrupo tela = new TelaAlterarGrupo();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiAlterarGrupoActionPerformed

    private void jmiAlterarSubgrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiAlterarSubgrupoActionPerformed
        TelaAlterarSubgrupo tela = new TelaAlterarSubgrupo();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiAlterarSubgrupoActionPerformed

    private void jmiDelogarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jmiDelogarMouseClicked
        TelaLogin tela = new TelaLogin();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiDelogarMouseClicked

    private void jbCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCadastrarActionPerformed
        if(
            !jtfCadastroCliente.getText().isBlank()
            && !jtfCadastroGrupo.getText().isBlank()
            && !jtfCadastroSubgrupo.getText().isBlank()
            && (jrbEntrada.isSelected() || jrbSaida.isSelected())
          )
        {
            ClienteDAO cliente = new ClienteDAO();
            GrupoDAO grupo = new GrupoDAO();
            SubgrupoDAO subGrupo = new SubgrupoDAO();
            if(
                cliente.hasID(jtfCadastroCliente.getText())
                && grupo.hasID(jtfCadastroGrupo.getText())
                && subGrupo.hasID(jtfCadastroSubgrupo.getText())
                && subGrupo.subgrupoHasGrupo(jtfCadastroGrupo.getText(), jtfCadastroSubgrupo.getText())
              )
            {
                TransacaoDAO dao = new TransacaoDAO();
                Transacao transacao = new Transacao();
                transacao.setIdCliente(Integer.parseInt(jtfCadastroCliente.getText()));
                transacao.setIdGrupo(Integer.parseInt(jtfCadastroGrupo.getText()));
                transacao.setIdSubgrupo(Integer.parseInt(jtfCadastroSubgrupo.getText()));
                transacao.setIdUsuario(UsuarioIDTransfer.getLoginID());
                transacao.setDataTransacao(getDateTimeForMYSQL());
                if (jrbEntrada.isSelected())
                {
                    transacao.setTipoTransacao(1);
                } else if (jrbSaida.isSelected())
                {
                    transacao.setTipoTransacao(0);
                }
                if(!jffDataPagamento.getText().replaceAll("/", "").replaceAll("_", "").isBlank())
                {
                    transacao.setDataPagamento(formatTime(jffDataPagamento.getText())+" 00:00:00");
                }
                dao.cadastrarTransacao(transacao);
            }else{
                JOptionPane.showMessageDialog(null, "Erro ao cadastrar Transação.");
            }
        }
    }//GEN-LAST:event_jbCadastrarActionPerformed

    private void jtfCadastroGrupoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtfCadastroGrupoKeyReleased
        atualizaTabela("subgrupo", jtTabelaSubgrupo);
    }//GEN-LAST:event_jtfCadastroGrupoKeyReleased

    private void jtfValorFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtfValorFocusGained
        if (jtfValor.getText().equals("R$ 0000,00"))
        {
            jtfValor.setText("");
            jtfValor.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_jtfValorFocusGained

    private void jtfValorFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtfValorFocusLost
        if (jtfValor.getText().isEmpty())
        {
            jtfValor.setForeground(Color.GRAY);
            jtfValor.setText("R$ 0000,00");
        }
    }//GEN-LAST:event_jtfValorFocusLost

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() {
                new TelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jbCadastrar;
    private javax.swing.ButtonGroup jbgTipoTransacao;
    private javax.swing.JFormattedTextField jffDataPagamento;
    private javax.swing.JLabel jlCadastroCliente;
    private javax.swing.JLabel jlCadastroGrupo;
    private javax.swing.JLabel jlCadastroSubgrupo;
    private javax.swing.JLabel jlDataPagamento;
    private javax.swing.JLabel jlValor;
    private javax.swing.JMenu jmAlterar;
    private javax.swing.JMenu jmCadastrar;
    private javax.swing.JMenuBar jmbMenu;
    private javax.swing.JMenuItem jmiAlterarCliente;
    private javax.swing.JMenuItem jmiAlterarGrupo;
    private javax.swing.JMenuItem jmiAlterarSubgrupo;
    private javax.swing.JMenuItem jmiCadastrarCliente;
    private javax.swing.JMenuItem jmiCadastrarGrupo;
    private javax.swing.JMenuItem jmiCadastrarSubgrupo;
    private javax.swing.JMenu jmiDelogar;
    private javax.swing.JMenu jmiFiller;
    private javax.swing.JMenu jmiSair1;
    private javax.swing.JPanel jpCliente;
    private javax.swing.JPanel jpEspacador;
    private javax.swing.JPanel jpGrupo;
    private javax.swing.JPanel jpSubgrupo;
    private javax.swing.JPanel jpTransacao;
    private javax.swing.JRadioButton jrbEntrada;
    private javax.swing.JRadioButton jrbSaida;
    private javax.swing.JScrollPane jspTabelaCliente;
    private javax.swing.JScrollPane jspTabelaGrupo;
    private javax.swing.JScrollPane jspTabelaSubgrupo;
    private javax.swing.JTable jtTabelaCliente;
    private javax.swing.JTable jtTabelaGrupo;
    private javax.swing.JTable jtTabelaSubgrupo;
    private javax.swing.JTextField jtfCadastroCliente;
    private javax.swing.JTextField jtfCadastroGrupo;
    private javax.swing.JTextField jtfCadastroSubgrupo;
    private javax.swing.JTextField jtfValor;
    // End of variables declaration//GEN-END:variables
}
