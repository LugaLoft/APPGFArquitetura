package Telas;

import Telas.Alterar.TelaAlterarCliente;
import Telas.Alterar.TelaAlterarGrupo;
import Telas.Alterar.TelaAlterarSubgrupo;
import Telas.Cadastrar.TelaCadastrarCliente;
import Telas.Cadastrar.TelaCadastrarGrupo;
import Telas.Cadastrar.TelaCadastrarSubgrupo;


public class TelaPrincipal extends javax.swing.JFrame
{

    public TelaPrincipal()
    {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jmbMenu = new javax.swing.JMenuBar();
        jmCadastrar = new javax.swing.JMenu();
        jmiCadastrarCliente = new javax.swing.JMenuItem();
        jmiCadastrarGrupo = new javax.swing.JMenuItem();
        jmiCadastrarSubgrupo = new javax.swing.JMenuItem();
        jmAlterar = new javax.swing.JMenu();
        jmiAlterarCliente = new javax.swing.JMenuItem();
        jmiAlterarGrupo = new javax.swing.JMenuItem();
        jmiAlterarSubgrupo = new javax.swing.JMenuItem();
        jmiFiller = new javax.swing.JMenu();
        jmiSair1 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jmbMenu.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N

        jmCadastrar.setText("Cadastrar");
        jmCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jmiCadastrarCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarCliente.setText("Cliente");
        jmiCadastrarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiCadastrarClienteActionPerformed(evt);
            }
        });
        jmCadastrar.add(jmiCadastrarCliente);

        jmiCadastrarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarGrupo.setText("Grupo");
        jmiCadastrarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiCadastrarGrupoActionPerformed(evt);
            }
        });
        jmCadastrar.add(jmiCadastrarGrupo);

        jmiCadastrarSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarSubgrupo.setText("SubGrupo");
        jmiCadastrarSubgrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiCadastrarSubgrupoActionPerformed(evt);
            }
        });
        jmCadastrar.add(jmiCadastrarSubgrupo);

        jmbMenu.add(jmCadastrar);

        jmAlterar.setText("Alterar");
        jmAlterar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jmiAlterarCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarCliente.setText("Cliente");
        jmiAlterarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiAlterarClienteActionPerformed(evt);
            }
        });
        jmAlterar.add(jmiAlterarCliente);

        jmiAlterarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarGrupo.setText("Grupo");
        jmiAlterarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiAlterarGrupoActionPerformed(evt);
            }
        });
        jmAlterar.add(jmiAlterarGrupo);

        jmiAlterarSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarSubgrupo.setText("SubGrupo");
        jmiAlterarSubgrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiAlterarSubgrupoActionPerformed(evt);
            }
        });
        jmAlterar.add(jmiAlterarSubgrupo);

        jmbMenu.add(jmAlterar);

        jmiFiller.setText("                                                              ");
        jmiFiller.setBorderPainted(false);
        jmiFiller.setContentAreaFilled(false);
        jmiFiller.setEnabled(false);
        jmiFiller.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmbMenu.add(jmiFiller);

        jmiSair1.setText("Sair");
        jmiSair1.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiSair1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jmiSair1MouseClicked(evt);
            }
        });
        jmbMenu.add(jmiSair1);

        setJMenuBar(jmbMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 845, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jmiSair1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jmiSair1MouseClicked
        dispose();
    }//GEN-LAST:event_jmiSair1MouseClicked

    private void jmiCadastrarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiCadastrarClienteActionPerformed
        TelaCadastrarCliente tela = new TelaCadastrarCliente();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiCadastrarClienteActionPerformed

    private void jmiCadastrarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiCadastrarGrupoActionPerformed
        TelaCadastrarGrupo tela = new TelaCadastrarGrupo();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiCadastrarGrupoActionPerformed

    private void jmiCadastrarSubgrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiCadastrarSubgrupoActionPerformed
        TelaCadastrarSubgrupo tela = new TelaCadastrarSubgrupo();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiCadastrarSubgrupoActionPerformed

    private void jmiAlterarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiAlterarClienteActionPerformed
        TelaAlterarCliente tela = new TelaAlterarCliente();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiAlterarClienteActionPerformed

    private void jmiAlterarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiAlterarGrupoActionPerformed
        TelaAlterarGrupo tela = new TelaAlterarGrupo();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiAlterarGrupoActionPerformed

    private void jmiAlterarSubgrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiAlterarSubgrupoActionPerformed
        TelaAlterarSubgrupo tela = new TelaAlterarSubgrupo();
        tela.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiAlterarSubgrupoActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() {
                new TelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jmAlterar;
    private javax.swing.JMenu jmCadastrar;
    private javax.swing.JMenuBar jmbMenu;
    private javax.swing.JMenuItem jmiAlterarCliente;
    private javax.swing.JMenuItem jmiAlterarGrupo;
    private javax.swing.JMenuItem jmiAlterarSubgrupo;
    private javax.swing.JMenuItem jmiCadastrarCliente;
    private javax.swing.JMenuItem jmiCadastrarGrupo;
    private javax.swing.JMenuItem jmiCadastrarSubgrupo;
    private javax.swing.JMenu jmiFiller;
    private javax.swing.JMenu jmiSair1;
    // End of variables declaration//GEN-END:variables
}
