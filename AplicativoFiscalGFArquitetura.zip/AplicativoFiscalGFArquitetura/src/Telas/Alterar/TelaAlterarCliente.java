package Telas.Alterar;

import DAO.ClienteDAO;
import Classes.Cliente;
import Telas.TelaPrincipal;
import java.awt.Component;
import java.text.ParseException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.text.MaskFormatter;

public class TelaAlterarCliente extends javax.swing.JFrame
{

    MaskFormatter telefoneFormat;
    
    public TelaAlterarCliente()
    {
        try
        {
            telefoneFormat = new MaskFormatter("(##) #####-####");
            telefoneFormat.setPlaceholderCharacter('_');
            
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao aplicar máscaras");
        }
        
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
        
        atualizaTabela();
    }
    
    public void atualizaTabela()
    {
        DefaultTableModel tabelaCliente = (DefaultTableModel) jtTabela.getModel();
        tabelaCliente.setRowCount(0);
        ClienteDAO userPaciente = new ClienteDAO();
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        listaClientes = userPaciente.getClientes();
        for(Cliente cliente: listaClientes)
        {
            String telefoneFormatado = "("+cliente.getTelefone().substring(0, 2)+") "+cliente.getTelefone().substring(2, 7)+"-"+cliente.getTelefone().substring(7, 11);
            Object[] linha ={cliente.getIdCliente(),cliente.getNome(),telefoneFormatado};
            tabelaCliente.addRow(linha);
        }
        
        for (int column = 0; column < jtTabela.getColumnCount(); column++)
        {
            TableColumn tableColumn = jtTabela.getColumnModel().getColumn(column);
            int preferredWidth = tableColumn.getMinWidth();
            int maxWidth = tableColumn.getMaxWidth();

            for (int row = 0; row < jtTabela.getRowCount(); row++)
            {
                TableCellRenderer cellRenderer = jtTabela.getCellRenderer(row, column);
                Component c = jtTabela.prepareRenderer(cellRenderer, row, column);
                int width = c.getPreferredSize().width + jtTabela.getIntercellSpacing().width;
                preferredWidth = Math.max(preferredWidth, width);

                if (preferredWidth >= maxWidth)
                {
                    preferredWidth = maxWidth;
                    break;
                }
            }
            tableColumn.setPreferredWidth( preferredWidth);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jlCadastro = new javax.swing.JLabel();
        jtfCadastro = new javax.swing.JTextField();
        jlNovoTelefone = new javax.swing.JLabel();
        jffNovoTelefone = new javax.swing.JFormattedTextField(telefoneFormat);
        jbVoltar = new javax.swing.JButton();
        jbAlterar = new javax.swing.JButton();
        jspTabela = new javax.swing.JScrollPane();
        jtTabela = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlCadastro.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlCadastro.setText("Cadastro do Cliente");

        jtfCadastro.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlNovoTelefone.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNovoTelefone.setText("Novo Telefone");

        jffNovoTelefone.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jbVoltar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbVoltar.setText("Voltar");
        jbVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbVoltarActionPerformed(evt);
            }
        });

        jbAlterar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbAlterar.setText("Alterar");
        jbAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAlterarActionPerformed(evt);
            }
        });

        jspTabela.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jtTabela.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jtTabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "N° Cliente", "Nome do Cliente", "Telefone"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtTabela.setRowHeight(50);
        jspTabela.setViewportView(jtTabela);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbVoltar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jbAlterar)
                .addGap(200, 200, 200))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jlCadastro)
                    .addComponent(jlNovoTelefone))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtfCadastro, javax.swing.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jffNovoTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jspTabela, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlCadastro))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlNovoTelefone)
                    .addComponent(jffNovoTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbVoltar)
                    .addComponent(jbAlterar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspTabela, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbVoltarActionPerformed
        dispose();
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
    }//GEN-LAST:event_jbVoltarActionPerformed

    private void jbAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAlterarActionPerformed
        ClienteDAO dao = new ClienteDAO();
        if(!jtfCadastro.getText().isBlank() && !jffNovoTelefone.getText().isBlank() && dao.hasID(jtfCadastro.getText()))
        {
            
            dao.alterarCliente(Integer.parseInt(jtfCadastro.getText()), jffNovoTelefone.getText().replaceAll("\\(", "").replaceAll("\\)", "").replaceAll("-", "").replaceAll(" ", ""));
            JOptionPane.showMessageDialog(null, "Telefone do paciente alterado com sucesso!");
            jffNovoTelefone.setText("");
            jtfCadastro.setText("");
            atualizaTabela();
        }else{
            JOptionPane.showMessageDialog(null, "Preenchimento dos campos inválidos.");
        }
    }//GEN-LAST:event_jbAlterarActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new TelaAlterarCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jbAlterar;
    private javax.swing.JButton jbVoltar;
    private javax.swing.JFormattedTextField jffNovoTelefone;
    private javax.swing.JLabel jlCadastro;
    private javax.swing.JLabel jlNovoTelefone;
    private javax.swing.JScrollPane jspTabela;
    private javax.swing.JTable jtTabela;
    private javax.swing.JTextField jtfCadastro;
    // End of variables declaration//GEN-END:variables
}
