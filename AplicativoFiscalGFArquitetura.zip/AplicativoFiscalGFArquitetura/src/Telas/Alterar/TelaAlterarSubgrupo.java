package Telas.Alterar;

import DAO.SubgrupoDAO;
import Telas.TelaPrincipal;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

public class TelaAlterarSubgrupo extends javax.swing.JFrame
{

    public TelaAlterarSubgrupo()
    {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
        
        atualizaTabela();
    }
    
    public void atualizaTabela()
    {
        DefaultTableModel tabelaCliente = (DefaultTableModel) jtTabela.getModel();
        tabelaCliente.setRowCount(0);
        SubgrupoDAO dao = new SubgrupoDAO();
        ArrayList<Object> listaGHS = dao.getSubgruposByGrupo();

        for (Object elemento : listaGHS)
        {
            tabelaCliente.addRow(((ArrayList<Object>) elemento).toArray());
        }
        
        for (int column = 0; column < jtTabela.getColumnCount(); column++)
        {
            TableColumn tableColumn = jtTabela.getColumnModel().getColumn(column);
            int preferredWidth = tableColumn.getMinWidth();
            int maxWidth = tableColumn.getMaxWidth();

            for (int row = 0; row < jtTabela.getRowCount(); row++)
            {
                TableCellRenderer cellRenderer = jtTabela.getCellRenderer(row, column);
                Component c = jtTabela.prepareRenderer(cellRenderer, row, column);
                int width = c.getPreferredSize().width + jtTabela.getIntercellSpacing().width;
                preferredWidth = Math.max(preferredWidth, width);

                if (preferredWidth >= maxWidth)
                {
                    preferredWidth = maxWidth;
                    break;
                }
            }
            tableColumn.setPreferredWidth( preferredWidth);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jlCadastro = new javax.swing.JLabel();
        jtfCadastro = new javax.swing.JTextField();
        jlNovoNome = new javax.swing.JLabel();
        jtfNovoNome = new javax.swing.JTextField();
        jlNovaDescricao = new javax.swing.JLabel();
        jspNovaDescricao = new javax.swing.JScrollPane();
        jtaNovaDescricao = new javax.swing.JTextArea();
        jbVoltar = new javax.swing.JButton();
        jbAlterar = new javax.swing.JButton();
        jspTabela = new javax.swing.JScrollPane();
        jtTabela = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlCadastro.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlCadastro.setText("Cadastro do Subgrupo");

        jtfCadastro.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlNovoNome.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNovoNome.setText("Novo Nome");

        jtfNovoNome.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlNovaDescricao.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNovaDescricao.setText("Nova Descrição");

        jtaNovaDescricao.setColumns(20);
        jtaNovaDescricao.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jtaNovaDescricao.setLineWrap(true);
        jtaNovaDescricao.setRows(1);
        jspNovaDescricao.setViewportView(jtaNovaDescricao);

        jbVoltar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbVoltar.setText("Voltar");
        jbVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbVoltarActionPerformed(evt);
            }
        });

        jbAlterar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbAlterar.setText("Alterar");
        jbAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAlterarActionPerformed(evt);
            }
        });

        jspTabela.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jtTabela.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jtTabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Cadastro Grupo", "Nome Grupo", "Cadastro Subgrupo", "Nome Subgrupo", "Descrição Subgrupo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtTabela.setRowHeight(50);
        jspTabela.setViewportView(jtTabela);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jspTabela, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbVoltar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jbAlterar)
                .addGap(204, 204, 204))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtfCadastro, javax.swing.GroupLayout.DEFAULT_SIZE, 694, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jlCadastro)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jlNovoNome)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jtfNovoNome)
                            .addComponent(jspNovaDescricao, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jlNovaDescricao)
                                .addGap(330, 441, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlCadastro)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlNovoNome)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfNovoNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jlNovaDescricao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspNovaDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbVoltar)
                    .addComponent(jbAlterar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jspTabela, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbVoltarActionPerformed
        dispose();
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
    }//GEN-LAST:event_jbVoltarActionPerformed

    private void jbAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAlterarActionPerformed
        if(!jtfCadastro.getText().isBlank() && !jtfNovoNome.getText().isBlank() && !jtaNovaDescricao.getText().isBlank())
        {
            SubgrupoDAO dao = new SubgrupoDAO();
            dao.alterarSubgrupoNome(Integer.parseInt(jtfCadastro.getText()), jtfNovoNome.getText());
            dao.alterarSubgrupoDescicao(Integer.parseInt(jtfCadastro.getText()), jtaNovaDescricao.getText());
            JOptionPane.showMessageDialog(null, "Nome do SubGrupo alterado com sucesso!");
            jtfNovoNome.setText("");
            jtfCadastro.setText("");
            jtaNovaDescricao.setText("");
            atualizaTabela();
        }else{
            JOptionPane.showMessageDialog(null, "Preenchimento dos campos inválidos.");
        }
    }//GEN-LAST:event_jbAlterarActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new TelaAlterarSubgrupo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jbAlterar;
    private javax.swing.JButton jbVoltar;
    private javax.swing.JLabel jlCadastro;
    private javax.swing.JLabel jlNovaDescricao;
    private javax.swing.JLabel jlNovoNome;
    private javax.swing.JScrollPane jspNovaDescricao;
    private javax.swing.JScrollPane jspTabela;
    private javax.swing.JTable jtTabela;
    private javax.swing.JTextArea jtaNovaDescricao;
    private javax.swing.JTextField jtfCadastro;
    private javax.swing.JTextField jtfNovoNome;
    // End of variables declaration//GEN-END:variables
}
