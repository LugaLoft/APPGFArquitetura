package Telas.Alterar;

import Classes.Grupo;
import DAO.GrupoDAO;
import Telas.TelaPrincipal;
import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

public class TelaAlterarGrupo extends javax.swing.JFrame
{

    public TelaAlterarGrupo()
    {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
        
        atualizaTabela();
    }

    public void atualizaTabela()
    {
        DefaultTableModel tabelaCliente = (DefaultTableModel) jtTabela.getModel();
        tabelaCliente.setRowCount(0);
        GrupoDAO user = new GrupoDAO();
        ArrayList<Grupo> listaGrupos = new ArrayList<>();
        listaGrupos = user.getGrupos();
        for(Grupo grupo: listaGrupos)
        {
            Object[] linha ={grupo.getIdGrupo(),grupo.getNome(), grupo.getDescricao()};
            tabelaCliente.addRow(linha);
        }
        
        for (int column = 0; column < jtTabela.getColumnCount(); column++)
        {
            TableColumn tableColumn = jtTabela.getColumnModel().getColumn(column);
            int preferredWidth = tableColumn.getMinWidth();
            int maxWidth = tableColumn.getMaxWidth();

            for (int row = 0; row < jtTabela.getRowCount(); row++)
            {
                TableCellRenderer cellRenderer = jtTabela.getCellRenderer(row, column);
                Component c = jtTabela.prepareRenderer(cellRenderer, row, column);
                int width = c.getPreferredSize().width + jtTabela.getIntercellSpacing().width;
                preferredWidth = Math.max(preferredWidth, width);

                if (preferredWidth >= maxWidth)
                {
                    preferredWidth = maxWidth;
                    break;
                }
            }
            tableColumn.setPreferredWidth( preferredWidth);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jlCadastro = new javax.swing.JLabel();
        jtfCadastro = new javax.swing.JTextField();
        jlNovoNome = new javax.swing.JLabel();
        jtfNovoNome = new javax.swing.JTextField();
        jlNovaDescricao = new javax.swing.JLabel();
        jspNovaDescricao = new javax.swing.JScrollPane();
        jtaNovaDescricao = new javax.swing.JTextArea();
        jbVoltar = new javax.swing.JButton();
        jbAlterar = new javax.swing.JButton();
        jspTabela = new javax.swing.JScrollPane();
        jtTabela = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlCadastro.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlCadastro.setText("Cadastro do Grupo");

        jtfCadastro.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlNovoNome.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNovoNome.setText("Novo Nome");

        jtfNovoNome.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlNovaDescricao.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNovaDescricao.setText("Nova Descrição");

        jtaNovaDescricao.setColumns(20);
        jtaNovaDescricao.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jtaNovaDescricao.setLineWrap(true);
        jtaNovaDescricao.setRows(1);
        jspNovaDescricao.setViewportView(jtaNovaDescricao);

        jbVoltar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbVoltar.setText("Voltar");
        jbVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbVoltarActionPerformed(evt);
            }
        });

        jbAlterar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbAlterar.setText("Alterar");
        jbAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbAlterarActionPerformed(evt);
            }
        });

        jspTabela.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jtTabela.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jtTabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "N° Cliente", "Nome do Grupo", "Descrição do Grupo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtTabela.setRowHeight(50);
        jspTabela.setViewportView(jtTabela);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jspTabela, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 225, Short.MAX_VALUE)
                        .addComponent(jbVoltar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbAlterar)
                        .addGap(201, 201, 201))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jlNovaDescricao)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jtfCadastro, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlCadastro, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jspNovaDescricao)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jlNovoNome)
                                .addGap(386, 386, 386))
                            .addComponent(jtfNovoNome, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addContainerGap())))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jlCadastro)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfCadastro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlNovoNome)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfNovoNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlNovaDescricao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspNovaDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbVoltar)
                    .addComponent(jbAlterar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jspTabela, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbVoltarActionPerformed
        dispose();
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
    }//GEN-LAST:event_jbVoltarActionPerformed

    private void jbAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbAlterarActionPerformed
        if(!jtfCadastro.getText().isBlank() && !jtfNovoNome.getText().isBlank() && !jtaNovaDescricao.getText().isBlank())
        {
            GrupoDAO dao = new GrupoDAO();
            dao.alterarGrupoNome(Integer.parseInt(jtfCadastro.getText()), jtfNovoNome.getText());
            dao.alterarGrupoDescicao(Integer.parseInt(jtfCadastro.getText()), jtaNovaDescricao.getText());
            JOptionPane.showMessageDialog(null, "Nome do Grupo alterado com sucesso!");
            jtfNovoNome.setText("");
            jtfCadastro.setText("");
            jtaNovaDescricao.setText("");
            atualizaTabela();
        }else{
            JOptionPane.showMessageDialog(null, "Preenchimento dos campos inválidos.");
        }
    }//GEN-LAST:event_jbAlterarActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new TelaAlterarGrupo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jbAlterar;
    private javax.swing.JButton jbVoltar;
    private javax.swing.JLabel jlCadastro;
    private javax.swing.JLabel jlNovaDescricao;
    private javax.swing.JLabel jlNovoNome;
    private javax.swing.JScrollPane jspNovaDescricao;
    private javax.swing.JScrollPane jspTabela;
    private javax.swing.JTable jtTabela;
    private javax.swing.JTextArea jtaNovaDescricao;
    private javax.swing.JTextField jtfCadastro;
    private javax.swing.JTextField jtfNovoNome;
    // End of variables declaration//GEN-END:variables
}
