package Telas.Cadastrar;

import DAO.GrupoDAO;
import Classes.Grupo;
import Telas.TelaPrincipal;
import javax.swing.JOptionPane;

public class TelaCadastrarGrupo extends javax.swing.JFrame {

    public TelaCadastrarGrupo()
    {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpCadastrarGrupo = new javax.swing.JPanel();
        jlNomeGrupo = new javax.swing.JLabel();
        jtfNomeGrupo = new javax.swing.JTextField();
        jlDescricaoGrupo = new javax.swing.JLabel();
        jbVoltarGrupo = new javax.swing.JButton();
        jbCadastrarGrupo = new javax.swing.JButton();
        jspDescricao = new javax.swing.JScrollPane();
        jtaDescricao = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlNomeGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNomeGrupo.setText("Nome");

        jtfNomeGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlDescricaoGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlDescricaoGrupo.setText("Descrição");

        jbVoltarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbVoltarGrupo.setText("Voltar");
        jbVoltarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbVoltarGrupoActionPerformed(evt);
            }
        });

        jbCadastrarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbCadastrarGrupo.setText("Cadastrar");
        jbCadastrarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCadastrarGrupoActionPerformed(evt);
            }
        });

        jtaDescricao.setColumns(20);
        jtaDescricao.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jtaDescricao.setLineWrap(true);
        jtaDescricao.setRows(1);
        jspDescricao.setViewportView(jtaDescricao);

        javax.swing.GroupLayout jpCadastrarGrupoLayout = new javax.swing.GroupLayout(jpCadastrarGrupo);
        jpCadastrarGrupo.setLayout(jpCadastrarGrupoLayout);
        jpCadastrarGrupoLayout.setHorizontalGroup(
            jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                .addGroup(jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpCadastrarGrupoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jspDescricao)
                            .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                                .addComponent(jlDescricaoGrupo)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                        .addGap(295, 295, 295)
                        .addComponent(jbVoltarGrupo)
                        .addGap(18, 18, 18)
                        .addComponent(jbCadastrarGrupo)
                        .addGap(0, 276, Short.MAX_VALUE))
                    .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jtfNomeGrupo)))
                .addContainerGap())
            .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlNomeGrupo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jpCadastrarGrupoLayout.setVerticalGroup(
            jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jlNomeGrupo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfNomeGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlDescricaoGrupo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspDescricao, javax.swing.GroupLayout.DEFAULT_SIZE, 118, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbVoltarGrupo)
                    .addComponent(jbCadastrarGrupo))
                .addGap(57, 57, 57))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastrarGrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastrarGrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbVoltarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbVoltarGrupoActionPerformed
        dispose();
        TelaPrincipal telaPrincipal = new TelaPrincipal();
        telaPrincipal.setVisible(true);
    }//GEN-LAST:event_jbVoltarGrupoActionPerformed

    private void jbCadastrarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCadastrarGrupoActionPerformed
        if(!jtfNomeGrupo.getText().isBlank() && !jtaDescricao.getText().isBlank())
        {
            GrupoDAO dao = new GrupoDAO();
            Grupo grupo = new Grupo(jtfNomeGrupo.getText(), jtaDescricao.getText());
            dao.cadastrarGrupo(grupo);
            jtfNomeGrupo.setText("");
            jtaDescricao.setText("");
        }else{
            JOptionPane.showMessageDialog(null, "Preenchimento dos campos inválidos.");
            jtfNomeGrupo.setText("");
            jtaDescricao.setText("");
        }
    }//GEN-LAST:event_jbCadastrarGrupoActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new TelaCadastrarGrupo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jbCadastrarGrupo;
    private javax.swing.JButton jbVoltarGrupo;
    private javax.swing.JLabel jlDescricaoGrupo;
    private javax.swing.JLabel jlNomeGrupo;
    private javax.swing.JPanel jpCadastrarGrupo;
    private javax.swing.JScrollPane jspDescricao;
    private javax.swing.JTextArea jtaDescricao;
    private javax.swing.JTextField jtfNomeGrupo;
    // End of variables declaration//GEN-END:variables
}
