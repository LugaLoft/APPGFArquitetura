package Telas.Cadastrar;

import DAO.GrupoDAO;
import Classes.Grupo;
import Telas.TelaPrincipal;
import javax.swing.JOptionPane;

public class TelaCadastrarGrupo extends javax.swing.JFrame {

    public TelaCadastrarGrupo()
    {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpCadastrarGrupo = new javax.swing.JPanel();
        jlNomeGrupo = new javax.swing.JLabel();
        jtfNomeGrupo = new javax.swing.JTextField();
        jlDescricaoGrupo = new javax.swing.JLabel();
        jtfDescricaoGrupo = new javax.swing.JTextField();
        jbVoltarGrupo = new javax.swing.JButton();
        jbCadastrarGrupo = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlNomeGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNomeGrupo.setText("Nome");

        jtfNomeGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlDescricaoGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlDescricaoGrupo.setText("Descrição");

        jtfDescricaoGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jbVoltarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbVoltarGrupo.setText("Voltar");
        jbVoltarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbVoltarGrupoActionPerformed(evt);
            }
        });

        jbCadastrarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbCadastrarGrupo.setText("Cadastrar");
        jbCadastrarGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCadastrarGrupoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jpCadastrarGrupoLayout = new javax.swing.GroupLayout(jpCadastrarGrupo);
        jpCadastrarGrupo.setLayout(jpCadastrarGrupoLayout);
        jpCadastrarGrupoLayout.setHorizontalGroup(
            jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jlDescricaoGrupo)
                    .addComponent(jlNomeGrupo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtfDescricaoGrupo)
                    .addComponent(jtfNomeGrupo))
                .addContainerGap())
            .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                .addGap(295, 295, 295)
                .addComponent(jbVoltarGrupo)
                .addGap(18, 18, 18)
                .addComponent(jbCadastrarGrupo)
                .addContainerGap(282, Short.MAX_VALUE))
        );
        jpCadastrarGrupoLayout.setVerticalGroup(
            jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastrarGrupoLayout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlNomeGrupo)
                    .addComponent(jtfNomeGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlDescricaoGrupo)
                    .addComponent(jtfDescricaoGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                .addGroup(jpCadastrarGrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbVoltarGrupo)
                    .addComponent(jbCadastrarGrupo))
                .addGap(57, 57, 57))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastrarGrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastrarGrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbVoltarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbVoltarGrupoActionPerformed
        dispose();
        TelaPrincipal telaPrincipal = new TelaPrincipal();
        telaPrincipal.setVisible(true);
    }//GEN-LAST:event_jbVoltarGrupoActionPerformed

    private void jbCadastrarGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCadastrarGrupoActionPerformed
        if(!jtfNomeGrupo.getText().isBlank() && !jtfDescricaoGrupo.getText().isBlank())
        {
            GrupoDAO dao = new GrupoDAO();
            Grupo grupo = new Grupo(jtfNomeGrupo.getText(), jtfDescricaoGrupo.getText());
            dao.cadastrarGrupo(grupo);
            jtfNomeGrupo.setText("");
            jtfDescricaoGrupo.setText("");
        }else{
            JOptionPane.showMessageDialog(null, "Preenchimento dos campos inválidos.");
            jtfNomeGrupo.setText("");
            jtfDescricaoGrupo.setText("");
        }
    }//GEN-LAST:event_jbCadastrarGrupoActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new TelaCadastrarGrupo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jbCadastrarGrupo;
    private javax.swing.JButton jbVoltarGrupo;
    private javax.swing.JLabel jlDescricaoGrupo;
    private javax.swing.JLabel jlNomeGrupo;
    private javax.swing.JPanel jpCadastrarGrupo;
    private javax.swing.JTextField jtfDescricaoGrupo;
    private javax.swing.JTextField jtfNomeGrupo;
    // End of variables declaration//GEN-END:variables
}
