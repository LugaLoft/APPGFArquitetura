package Telas.Cadastrar;

import DAO.ClienteDAO;
import Classes.Cliente;
import Telas.TelaPrincipal;
import java.text.ParseException;
import javax.swing.JOptionPane;
import javax.swing.text.MaskFormatter;

public class TelaCadastrarCliente extends javax.swing.JFrame
{

    MaskFormatter cnpjFormat;
    MaskFormatter telefoneFormat;
    
    public TelaCadastrarCliente()
    {
        try
        {
            cnpjFormat = new MaskFormatter("##.###.###/####-##");
            cnpjFormat.setPlaceholderCharacter('_');
            
            telefoneFormat = new MaskFormatter("(##) #####-####");
            telefoneFormat.setPlaceholderCharacter('_');
            
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao aplicar máscaras");
        }
        
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpCadastro = new javax.swing.JPanel();
        jlCnpj = new javax.swing.JLabel();
        jffCnpj = new javax.swing.JFormattedTextField(cnpjFormat);
        jlNome = new javax.swing.JLabel();
        jffTelefone = new javax.swing.JFormattedTextField(telefoneFormat);
        jLabel3 = new javax.swing.JLabel();
        jtfNome = new javax.swing.JTextField();
        jbVoltar = new javax.swing.JButton();
        jbCadastrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlCnpj.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlCnpj.setText("CNPJ");

        jffCnpj.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlNome.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNome.setText("Nome");

        jffTelefone.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jLabel3.setText("Telefone");

        jtfNome.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jbVoltar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbVoltar.setText("Voltar");
        jbVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbVoltarActionPerformed(evt);
            }
        });

        jbCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbCadastrar.setText("Cadastrar");
        jbCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCadastrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jpCadastroLayout = new javax.swing.GroupLayout(jpCadastro);
        jpCadastro.setLayout(jpCadastroLayout);
        jpCadastroLayout.setHorizontalGroup(
            jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpCadastroLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jlNome)
                    .addComponent(jlCnpj))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jffCnpj, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtfNome, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpCadastroLayout.createSequentialGroup()
                .addGap(0, 88, Short.MAX_VALUE)
                .addGroup(jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpCadastroLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jffTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(196, 196, 196))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpCadastroLayout.createSequentialGroup()
                        .addComponent(jbVoltar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbCadastrar)
                        .addGap(182, 182, 182))))
        );
        jpCadastroLayout.setVerticalGroup(
            jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastroLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlCnpj)
                    .addComponent(jffCnpj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlNome)
                    .addComponent(jtfNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jffTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jpCadastroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbVoltar)
                    .addComponent(jbCadastrar))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbVoltarActionPerformed
        dispose();
        TelaPrincipal telaPrincipal = new TelaPrincipal();
        telaPrincipal.setVisible(true);
    }//GEN-LAST:event_jbVoltarActionPerformed

    private void jbCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCadastrarActionPerformed
        if(!jffCnpj.getText().isBlank() && !jtfNome.getText().isBlank() && !jffTelefone.getText().replaceAll("\\(", "").replaceAll("\\)", "").replaceAll(" ", "").replaceAll("-", "").isBlank())
        {
            ClienteDAO dao = new ClienteDAO();
            Cliente cliente = new Cliente(jffCnpj.getText(), jtfNome.getText(), jffTelefone.getText());
            dao.cadastrarCliente(cliente);
            jffCnpj.setText("");
            jtfNome.setText("");
            jffTelefone.setText("");
        }else{
            JOptionPane.showMessageDialog(null, "Preenchimento dos campos inválidos.");
            jtfNome.setText("");
            jffCnpj.setText("");
            jffTelefone.setText("");
        }
    }//GEN-LAST:event_jbCadastrarActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new TelaCadastrarCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton jbCadastrar;
    private javax.swing.JButton jbVoltar;
    private javax.swing.JFormattedTextField jffCnpj;
    private javax.swing.JFormattedTextField jffTelefone;
    private javax.swing.JLabel jlCnpj;
    private javax.swing.JLabel jlNome;
    private javax.swing.JPanel jpCadastro;
    private javax.swing.JTextField jtfNome;
    // End of variables declaration//GEN-END:variables
}
