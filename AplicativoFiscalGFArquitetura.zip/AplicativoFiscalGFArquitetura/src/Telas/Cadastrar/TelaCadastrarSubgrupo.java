package Telas.Cadastrar;

import Classes.Grupo;
import Classes.Subgrupo;
import DAO.GrupoDAO;
import DAO.SubgrupoDAO;
import Telas.TelaPrincipal;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class TelaCadastrarSubgrupo extends javax.swing.JFrame
{

    public TelaCadastrarSubgrupo()
    {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
        
        GrupoDAO dao = new GrupoDAO();
        ArrayList<Grupo> listaGrupos = new ArrayList<>();
        listaGrupos = dao.getGrupos();
        for(Grupo grupo: listaGrupos)
        {
            jcbGrupo.addItem(grupo.getNome());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpCadastrarSubgrupo = new javax.swing.JPanel();
        jlNome = new javax.swing.JLabel();
        jtfNome = new javax.swing.JTextField();
        jlDescricao = new javax.swing.JLabel();
        jspDescricao = new javax.swing.JScrollPane();
        jtaDescricao = new javax.swing.JTextArea();
        jbVoltar = new javax.swing.JButton();
        jbCadastrar = new javax.swing.JButton();
        jlGrupo = new javax.swing.JLabel();
        jcbGrupo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlNome.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNome.setText("Nome");

        jtfNome.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlDescricao.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlDescricao.setText("Descrição");

        jtaDescricao.setColumns(20);
        jtaDescricao.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jtaDescricao.setLineWrap(true);
        jtaDescricao.setRows(1);
        jspDescricao.setViewportView(jtaDescricao);

        jbVoltar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbVoltar.setText("Voltar");
        jbVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbVoltarActionPerformed(evt);
            }
        });

        jbCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbCadastrar.setText("Cadastrar");
        jbCadastrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCadastrarActionPerformed(evt);
            }
        });

        jlGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlGrupo.setText("Grupo");

        jcbGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        javax.swing.GroupLayout jpCadastrarSubgrupoLayout = new javax.swing.GroupLayout(jpCadastrarSubgrupo);
        jpCadastrarSubgrupo.setLayout(jpCadastrarSubgrupoLayout);
        jpCadastrarSubgrupoLayout.setHorizontalGroup(
            jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtfNome)
                            .addComponent(jspDescricao)
                            .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlNome)
                                    .addComponent(jlDescricao))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                        .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                                .addGap(291, 291, 291)
                                .addComponent(jbVoltar)
                                .addGap(18, 18, 18)
                                .addComponent(jbCadastrar))
                            .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jlGrupo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jcbGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, 541, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 253, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jpCadastrarSubgrupoLayout.setVerticalGroup(
            jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlNome)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfNome)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlDescricao)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jspDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlGrupo)
                    .addComponent(jcbGrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbVoltar)
                    .addComponent(jbCadastrar))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastrarSubgrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jpCadastrarSubgrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCadastrarActionPerformed
        String selectedItemIdText = String.valueOf(jcbGrupo.getSelectedIndex()+1);
        
        if(!jtfNome.getText().isBlank() && !jtaDescricao.getText().isBlank() && !selectedItemIdText.isBlank())
        {
            GrupoDAO gDAO = new GrupoDAO();
            SubgrupoDAO sDAO = new SubgrupoDAO();
            
            ArrayList<Grupo> listaG = gDAO.getGrupos();
            
            Subgrupo subGrupo = new Subgrupo(jtfNome.getText(), jtaDescricao.getText());
            Grupo grupo = new Grupo(Integer.parseInt(selectedItemIdText), listaG.getLast().getNome(), listaG.getLast().getDescricao());
            
            sDAO.cadastrarSubgrupo(subGrupo);
            
            ArrayList<Subgrupo> listaSG = sDAO.getSubgrupos();
            subGrupo.setIdSubgrupo(listaSG.getLast().getIdSubgrupo());
            sDAO.cadastrarGrupo_has_Subgrupo(grupo, subGrupo);
            
            jtfNome.setText("");
            jtaDescricao.setText("");
        }else{
            JOptionPane.showMessageDialog(null, "Preenchimento dos campos inválidos.");
            jtfNome.setText("");
            jtaDescricao.setText("");
        }
    }//GEN-LAST:event_jbCadastrarActionPerformed

    private void jbVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbVoltarActionPerformed
        dispose();
        TelaPrincipal telaPrincipal = new TelaPrincipal();
        telaPrincipal.setVisible(true);
    }//GEN-LAST:event_jbVoltarActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new TelaCadastrarSubgrupo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jbCadastrar;
    private javax.swing.JButton jbVoltar;
    private javax.swing.JComboBox<String> jcbGrupo;
    private javax.swing.JLabel jlDescricao;
    private javax.swing.JLabel jlGrupo;
    private javax.swing.JLabel jlNome;
    private javax.swing.JPanel jpCadastrarSubgrupo;
    private javax.swing.JScrollPane jspDescricao;
    private javax.swing.JTextArea jtaDescricao;
    private javax.swing.JTextField jtfNome;
    // End of variables declaration//GEN-END:variables
}
