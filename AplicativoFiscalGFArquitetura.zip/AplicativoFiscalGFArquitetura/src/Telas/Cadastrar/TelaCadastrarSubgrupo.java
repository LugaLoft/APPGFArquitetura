package Telas.Cadastrar;

import Classes.Grupo;
import Classes.Subgrupo;
import DAO.GrupoDAO;
import DAO.SubgrupoDAO;
import Telas.TelaPrincipal;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class TelaCadastrarSubgrupo extends javax.swing.JFrame
{

    public TelaCadastrarSubgrupo()
    {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
        
        GrupoDAO dao = new GrupoDAO();
        ArrayList<Grupo> listaGrupos = new ArrayList<>();
        listaGrupos = dao.getGrupos();
        for(Grupo grupo: listaGrupos)
        {
            jcbGrupo.addItem(grupo.getNome());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpCadastrarSubgrupo = new javax.swing.JPanel();
        jlNomeSubgrupo = new javax.swing.JLabel();
        jtfNomeSubgrupo = new javax.swing.JTextField();
        jlDescricaoSubgrupo = new javax.swing.JLabel();
        jtfDescricaoSubgrupo = new javax.swing.JTextField();
        jbVoltarSubgrupo = new javax.swing.JButton();
        jbCadastrarSubgrupo = new javax.swing.JButton();
        jlGrupo = new javax.swing.JLabel();
        jcbGrupo = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jlNomeSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlNomeSubgrupo.setText("Nome");

        jtfNomeSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jlDescricaoSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlDescricaoSubgrupo.setText("Descrição");

        jtfDescricaoSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jbVoltarSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbVoltarSubgrupo.setText("Voltar");
        jbVoltarSubgrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbVoltarSubgrupoActionPerformed(evt);
            }
        });

        jbCadastrarSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jbCadastrarSubgrupo.setText("Cadastrar");
        jbCadastrarSubgrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCadastrarSubgrupoActionPerformed(evt);
            }
        });

        jlGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jlGrupo.setText("Grupo");

        jcbGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        javax.swing.GroupLayout jpCadastrarSubgrupoLayout = new javax.swing.GroupLayout(jpCadastrarSubgrupo);
        jpCadastrarSubgrupo.setLayout(jpCadastrarSubgrupoLayout);
        jpCadastrarSubgrupoLayout.setHorizontalGroup(
            jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jlDescricaoSubgrupo)
                    .addComponent(jlNomeSubgrupo)
                    .addComponent(jlGrupo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtfDescricaoSubgrupo)
                    .addComponent(jtfNomeSubgrupo)
                    .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                        .addComponent(jcbGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                .addGap(292, 292, 292)
                .addComponent(jbVoltarSubgrupo)
                .addGap(18, 18, 18)
                .addComponent(jbCadastrarSubgrupo)
                .addContainerGap(297, Short.MAX_VALUE))
        );
        jpCadastrarSubgrupoLayout.setVerticalGroup(
            jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpCadastrarSubgrupoLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlNomeSubgrupo)
                    .addComponent(jtfNomeSubgrupo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlDescricaoSubgrupo)
                    .addComponent(jtfDescricaoSubgrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlGrupo)
                    .addComponent(jcbGrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(143, 143, 143)
                .addGroup(jpCadastrarSubgrupoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbVoltarSubgrupo)
                    .addComponent(jbCadastrarSubgrupo))
                .addGap(21, 21, 21))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastrarSubgrupo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jpCadastrarSubgrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbCadastrarSubgrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCadastrarSubgrupoActionPerformed
        String selectedItemIdText = String.valueOf(jcbGrupo.getSelectedIndex()+1);
        
        if(!jtfNomeSubgrupo.getText().isBlank() && !jtfDescricaoSubgrupo.getText().isBlank() && !selectedItemIdText.isBlank())
        {
            GrupoDAO gDAO = new GrupoDAO();
            SubgrupoDAO sDAO = new SubgrupoDAO();
            
            ArrayList<Grupo> listaG = gDAO.getGrupos();
            
            Subgrupo subGrupo = new Subgrupo(jtfNomeSubgrupo.getText(), jtfDescricaoSubgrupo.getText());
            Grupo grupo = new Grupo(Integer.parseInt(selectedItemIdText), listaG.getLast().getNome(), listaG.getLast().getDescricao());
            
            sDAO.cadastrarSubgrupo(subGrupo);
            
            ArrayList<Subgrupo> listaSG = sDAO.getSubgrupos();
            subGrupo.setIdSubgrupo(listaSG.getLast().getIdSubgrupo());
            sDAO.cadastrarGrupo_has_Subgrupo(grupo, subGrupo);
            
            jtfNomeSubgrupo.setText("");
            jtfDescricaoSubgrupo.setText("");
        }else{
            JOptionPane.showMessageDialog(null, "Preenchimento dos campos inválidos.");
            jtfNomeSubgrupo.setText("");
            jtfDescricaoSubgrupo.setText("");
        }
    }//GEN-LAST:event_jbCadastrarSubgrupoActionPerformed

    private void jbVoltarSubgrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbVoltarSubgrupoActionPerformed
        dispose();
        TelaPrincipal telaPrincipal = new TelaPrincipal();
        telaPrincipal.setVisible(true);
    }//GEN-LAST:event_jbVoltarSubgrupoActionPerformed

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new TelaCadastrarSubgrupo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jbCadastrar;
    private javax.swing.JButton jbCadastrarSubgrupo;
    private javax.swing.JButton jbVoltar;
    private javax.swing.JButton jbVoltarSubgrupo;
    private javax.swing.JComboBox<String> jcbGrupo;
    private javax.swing.JLabel jlDescricao;
    private javax.swing.JLabel jlDescricaoSubgrupo;
    private javax.swing.JLabel jlGrupo;
    private javax.swing.JLabel jlNome;
    private javax.swing.JLabel jlNomeSubgrupo;
    private javax.swing.JPanel jpCadastrarSubgrupo;
    private javax.swing.JPanel jpCadastro;
    private javax.swing.JTextField jtfDescricao;
    private javax.swing.JTextField jtfDescricaoSubgrupo;
    private javax.swing.JTextField jtfNome;
    private javax.swing.JTextField jtfNomeSubgrupo;
    // End of variables declaration//GEN-END:variables
}
