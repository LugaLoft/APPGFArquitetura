    package DAO;

import Classes.Subgrupo;
import Classes.Grupo;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class SubgrupoDAO
{
    private Connection connection;
    ResultSet rs;
    PreparedStatement pstm;
    
    public SubgrupoDAO()
    {
        this.connection = new ConexaoBanco().getConexao();
    }
    
    public void cadastrarSubgrupo(Subgrupo Subgrupo)
    {
        String sql = "insert into Subgrupo(nome, descricao)values(?,?)";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, Subgrupo.getNome());
            ps.setString(2, Subgrupo.getDescricao());
            
            ps.execute();
            ps.close();
            connection.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar Subgrupo. " + e);
        }
    }
    
    public void cadastrarGrupo_has_Subgrupo(Grupo grupo, Subgrupo subGrupo)
    {
        
        String sql = "insert into Grupo_has_Subgrupo(idGrupo, idSubgrupo)values(?,?)";
        
            try (Connection connection = new ConexaoBanco().getConexao();
                    PreparedStatement ps = connection.prepareStatement(sql))
            {
                ps.setInt(1, grupo.getIdGrupo());
                ps.setInt(2, subGrupo.getIdSubgrupo());

                
                ps.execute();
                ps.close();
                connection.close();
                JOptionPane.showMessageDialog(null, "Subgrupo cadastrado com sucesso.");
            }catch(Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar vínculo do Subgrupo. " + e);
        }
    }
    

    public ArrayList<Subgrupo> getSubgrupos()
    {
        String sql = "select * from Subgrupo";
        
        ArrayList<Subgrupo> Subgrupos = new ArrayList<>();
        
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    Subgrupo Subgrupo = new Subgrupo();
                    Subgrupo.setIdSubgrupo(rs.getInt("idSubgrupo"));
                    Subgrupo.setNome(rs.getString("nome"));
                    Subgrupo.setDescricao(rs.getString("descricao"));
                    Subgrupos.add(Subgrupo);
                }
            }
        return Subgrupos;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public String getSubgrupoNome(int idSubgrupo)
    {
        String sql = "select nome from Subgrupo where idSubgrupo = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idSubgrupo);
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    return rs.getString("nome");
                }    
            }
            rs.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
    
    public String getSubgrupoDescricao(int idSubSubgrupo)
    {
        String sql = "select descricao from Subgrupo where idSubgrupo = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idSubSubgrupo);
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    return rs.getString("descricao");
                }    
            }
            rs.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
    
    public void alterarSubgrupoNome(int idSubgrupo, String novoNome)
    {
        String sql = "update Subgrupo set nome = ? where idSubgrupo = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, novoNome);
            ps.setInt(2, idSubgrupo);
            ps.execute();
            ps.close();
            
            connection.close();
        } catch (Exception e) {
        }
    }
    
    public void alterarSubgrupoDescicao(int idSubgrupo, String novaDescricao)
    {
        String sql = "update Subgrupo set descricao = ? where idSubgrupo = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, novaDescricao);
            ps.setInt(2, idSubgrupo);
            ps.execute();
            ps.close();
            
            connection.close();
        } catch (Exception e) {
        }
    }
    
    public void excluirSubgrupo(int idSubgrupo) throws SQLException
    {
        String sql = "Delete from Subgrupo where idSubgrupo = ?";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idSubgrupo);
            ps.executeUpdate();
            connection.close();
        } catch (java.sql.SQLIntegrityConstraintViolationException e) {
            throw new SQLException("Erro ao excluir Subgrupo. Existem dependencias no cadastro.");
        }
    }
}