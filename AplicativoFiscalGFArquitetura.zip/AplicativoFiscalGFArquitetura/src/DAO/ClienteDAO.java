package DAO;

import Classes.Cliente;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ClienteDAO
{
    private Connection connection;
    ResultSet rs;
    PreparedStatement pstm;
    
    public ClienteDAO()
    {
        this.connection = new ConexaoBanco().getConexao();
    }
    
    public Cliente logar(String nome, String senha)
    {
        Cliente cliente = null;
        String sql = "select * from Cliente where nome = ? and  senha = ?";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql);)
        {
            ps.setString(1, nome);
            ps.setString(2, senha);
            try (ResultSet rs = ps.executeQuery())
            {
                if(rs.next())
                {
                    cliente = new Cliente();
                    cliente.setIdCliente(rs.getInt("idCliente"));
                    cliente.setCNPJ(rs.getString("CNPJ"));
                    cliente.setNome(rs.getString("nome"));
                    cliente.setTelefone(rs.getString("telefone"));

                    connection.close();
                }
            }
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        return cliente;
    }
    
    public void cadastrarCliente(Cliente cliente)
    {
        String sql = "insert into Cliente(CNPJ, nome, telefone)values(?,?,?)";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, cliente.getCNPJ().replaceAll("\\.", "").replaceAll("-", ""));
            ps.setString(2, cliente.getNome());
            ps.setString(3, cliente.getTelefone().replaceAll("\\(", "").replaceAll("\\)", "").replaceAll("-", "").replaceAll(" ", ""));
                        
            ps.execute();
            ps.close();
            connection.close();
            JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar Cliente. " + e);
        }
    }
    
    public ArrayList<Cliente> getClientes()
    {
        String sql = "select * from Cliente";
        
        ArrayList<Cliente> clientes = new ArrayList<>();
        
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    Cliente Cliente = new Cliente();
                    Cliente.setIdCliente(rs.getInt("idCliente"));
                    Cliente.setNome(rs.getString("nome"));
                    Cliente.setTelefone(rs.getString("telefone"));
                    clientes.add(Cliente);
                }
            }
        return clientes;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public String getClienteNome(int idCliente)
    {
        String sql = "select nome from Cliente where idCliente = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idCliente);
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    return rs.getString("nome");
                }    
            }
            rs.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
    
    public void alterarCliente(int idCliente, String novoTelefone)
    {
        String sql = "update Cliente set telefone = ? where idCliente = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, novoTelefone);
            ps.setInt(2, idCliente);
            ps.execute();
            ps.close();
            
            connection.close();
        } catch (Exception e) {
        }
    }
    
    public void excluirCliente(int idCliente) throws SQLException
    {
        String sql = "Delete from Cliente where idCliente = ?";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idCliente);
            ps.executeUpdate();
            connection.close();
        } catch (java.sql.SQLIntegrityConstraintViolationException e) {
            throw new SQLException("Erro ao excluir Cliente. Existem dependencias no cadastro.");
        }
    }
}
