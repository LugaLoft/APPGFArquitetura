package DAO;

/*
Imports de módulos pertinentes ao JFrameForm,
utilitários de programação, e Classes internas ao programa.
*/
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;

public class ConexaoBanco
{
    /*
    "Função Construtora" do conector com o banco de dados. É aqui que estabelecemos
    o link com o MYSQL utilizando, no momento, o XAMPP Control Panel.
    */
    public Connection getConexao()
    {
        try
        {
            return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/bancocris", "root","");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "A conexao com o banco de dados falhou.\nTente novamente.");
            return null;
        }
    }
}
