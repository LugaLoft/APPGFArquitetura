package DAO;

import Classes.Usuario;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class UsuarioDAO
{
    private Connection connection;
    ResultSet rs;
    PreparedStatement pstm;
    
    public UsuarioDAO()
    {
        this.connection = new ConexaoBanco().getConexao();
    }
    
    public Usuario logar(String login, String senha)
    {
        Usuario usuario = null;
        String sql = "select * from Usuario where login = ? and  senha = ?";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql);)
        {
            ps.setString(1, login);
            ps.setString(2, senha);
            try (ResultSet rs = ps.executeQuery())
            {
                if(rs.next())
                {
                    usuario = new Usuario();
                    usuario.setIdUsuario(rs.getInt("idUsuario"));
                    usuario.setNome(rs.getString("nome"));
                    usuario.setCpf(rs.getString("CPF"));
                    usuario.setLogin(rs.getString("login"));
                    usuario.setSenha(rs.getString("senha"));
                    connection.close();
                }
            }
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        return usuario;
    }
    
    public void cadastrarUsuario(Usuario usuario)
    {
        String sql = "insert into Usuario(nome, CPF, login, senha)values(?,?,?,?)";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getCpf().replaceAll("\\.", "").replaceAll("-", ""));
            ps.setString(3, usuario.getLogin());
            ps.setString(4, usuario.getSenha());

                        
            ps.execute();
            ps.close();
            connection.close();
            JOptionPane.showMessageDialog(null, "Usuario cadastrado com sucesso.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar Usuario. " + e);
        }
    }
    
    public ArrayList<Usuario> getUsuarios()
    {
        String sql = "select * from Usuario";
        
        ArrayList<Usuario> usuarios = new ArrayList<>();
        
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    Usuario usuario = new Usuario();
                    usuario.setNome(rs.getString("nome"));
                    usuario.setCpf(rs.getString("CPF"));
                    usuario.setLogin(rs.getString("login"));
                    usuario.setSenha(rs.getString("senha"));
                    usuarios.add(usuario);
                }
            }
        return usuarios;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public String getUsuarioNome(int idUsuario)
    {
        String sql = "select nome from Usuario where idUsuario = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idUsuario);
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    return rs.getString("nome");
                }    
            }
            rs.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
    
    public void alterarUsuario(int idUsuario, String novaSenha)
    {
        String sql = "update Usuario set senha = ? where idUsuario = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, novaSenha);
            ps.setInt(2, idUsuario);
            ps.execute();
            ps.close();
            
            connection.close();
        } catch (Exception e) {
        }
    }
    
    public void excluirUsuario(int idUsuario) throws SQLException
    {
        String sql = "Delete from Usuario where idUsuario = ?";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idUsuario);
            ps.executeUpdate();
            connection.close();
        } catch (java.sql.SQLIntegrityConstraintViolationException e) {
            throw new SQLException("Erro ao excluir Usuario. Existem dependencias no cadastro.");
        }
    }
}
