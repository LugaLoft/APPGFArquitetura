package Classes;

public class UsuarioIDTransfer
{
    private static Integer loginID;

    public static Integer getLoginID()
    {
        return loginID;
    }

    public static void setLoginID(Integer id)
    {
        loginID = id;
    }
}