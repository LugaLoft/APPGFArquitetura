package Classes;

public class Transacao
{
    private Integer idTransacao;
    private Integer idCliente;
    private Integer idGrupo;
    private Integer idSubgrupo;
    private Integer idUsuario;
    private String dataTransacao;
    private boolean tipoTransacao;
    private double valor;
    private String dataPagamento;

    public Transacao(Integer idTransacao,Integer idCliente, Integer idGrupo, Integer idSubgrupo, Integer idUsuario, String dataTransacao, boolean tipoTransacao, Double valor, String dataPagamento)
    {
        this.idTransacao = idTransacao;
        this.idCliente = idCliente;
        this.idGrupo = idGrupo;
        this.idSubgrupo = idSubgrupo;
        this.idUsuario = idUsuario;
        this.dataTransacao = dataTransacao;
        this.tipoTransacao = tipoTransacao;
        this.valor = valor;
        this.dataPagamento = dataPagamento;
    }
    
    public Transacao(Integer idTransacao, Integer idCliente, Integer idGrupo, Integer idSubgrupo, Integer idUsuario, String dataTransacao, boolean tipoTransacao)
    {
        this.idTransacao = idTransacao;
        this.idCliente = idCliente;
        this.idGrupo = idGrupo;
        this.idSubgrupo = idSubgrupo;
        this.idUsuario = idUsuario;
        this.dataTransacao = dataTransacao;
        this.tipoTransacao = tipoTransacao;
        this.dataPagamento = null;
    }

    public Transacao()
    {
    }
    
    public Integer getIdTransacao()
    {
        return idTransacao;
    }

    public void setIdTransacao(Integer idTransacao)
    {
        this.idTransacao = idTransacao;
    }

    public Integer getIdCliente()
    {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente)
    {
        this.idCliente = idCliente;
    }

    public Integer getIdGrupo()
    {
        return idGrupo;
    }

    public void setIdGrupo(Integer idGrupo)
    {
        this.idGrupo = idGrupo;
    }

    public Integer getIdSubgrupo()
    {
        return idSubgrupo;
    }

    public void setIdSubgrupo(Integer idSubgrupo)
    {
        this.idSubgrupo = idSubgrupo;
    }

    public Integer getIdUsuario()
    {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario)
    {
        this.idUsuario = idUsuario;
    }

    public String getDataTransacao()
    {
        return dataTransacao;
    }

    public void setDataTransacao(String dataTransacao)
    {
        this.dataTransacao = dataTransacao;
    }

    public boolean isTipoTransacao() {
        return tipoTransacao;
    }

    public void setTipoTransacao(boolean tipoTransacao)
    {
        this.tipoTransacao = tipoTransacao;
    }

    public double getValor()
    {
        return valor;
    }

    public void setValor(double valor)
    {
        this.valor = valor;
    }

    public String getDataPagamento()
    {
        return dataPagamento;
    }

    public void setDataPagamento(String dataPagamento)
    {
        this.dataPagamento = dataPagamento;
    }
}
