package Classes;

public class Cliente
{
    private Integer idCliente;
    private String CNPJ;
    private String nome;
    private String telefone;

    public Cliente()
    {
    }
    
    public Cliente(String CNPJ, String nome, String telefone)
    {
        this.CNPJ = CNPJ;
        this.nome = nome;
        this.telefone = telefone;
    }
    
    public Cliente(Integer idCliente, String CNPJ, String nome, String telefone)
    {
        this.idCliente = idCliente;
        this.CNPJ = CNPJ;
        this.nome = nome;
        this.telefone = telefone;
    }

    public Integer getIdCliente()
    {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente)
    {
        this.idCliente = idCliente;
    }

    public String getCNPJ()
    {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ)
    {
        this.CNPJ = CNPJ;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getTelefone()
    {
        return telefone;
    }

    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }
}
