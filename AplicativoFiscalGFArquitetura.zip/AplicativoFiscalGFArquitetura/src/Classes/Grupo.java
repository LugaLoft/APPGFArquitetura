package Classes;

public class Grupo
{
    Integer idGrupo;
    private String nome;
    private String descricao;

    public Grupo()
    {
    }

    public Grupo(String nome, String descricao)
    {
        this.nome = nome;
        this.descricao = descricao;
    }
    
    public Grupo(Integer idGrupo, String nome, String descricao)
    {
        this.idGrupo = idGrupo;
        this.nome = nome;
        this.descricao = descricao;
    }

    public Integer getIdGrupo()
    {
        return idGrupo;
    }

    public void setIdGrupo(Integer idGrupo)
    {
        this.idGrupo = idGrupo;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getDescricao()
    {
        return descricao;
    }

    public void setDescricao(String descricao)
    {
        this.descricao = descricao;
    }
    
    
}