package DAO;

import Classes.Transacao;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class TransacaoDAO
{
    private Connection connection;
    ResultSet rs;
    PreparedStatement pstm;
    
    public TransacaoDAO()
    {
        this.connection = new ConexaoBanco().getConexao();
    }
    
    public void cadastrarTransacao(Transacao transacao)
    {
        String sql = "insert into Transacao (idCliente, idGrupo, idSubgrupo, idUsuario, dataTransacao, tipoTransacao, valor, dataPagamento) values (?,?,?,?,?,?,?,?)";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            BigDecimal decimal = new BigDecimal(transacao.getValor());
            
            ps.setInt(1,transacao.getIdCliente());
            ps.setInt(2,transacao.getIdGrupo());
            ps.setInt(3,transacao.getIdSubgrupo());
            ps.setInt(4,transacao.getIdUsuario());
            ps.setTimestamp(5, Timestamp.valueOf(transacao.getDataTransacao()));
            ps.setBoolean(6, transacao.isTipoTransacao());
            ps.setBigDecimal(7, decimal);
            ps.setTimestamp(8, Timestamp.valueOf(transacao.getDataPagamento()));
                        
            ps.execute();
            ps.close();
            connection.close();
            JOptionPane.showMessageDialog(null, "Transação cadastrada com sucesso.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar Transação. " + e);
        }
    }
    
    public ArrayList<Transacao> getTransacoes(String nome)
    {
        String sql = "select * from Transacao where nome like '%?%'";
        
        ArrayList<Transacao> transacoes = new ArrayList<>();
        
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, nome);
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    Transacao transacao = new Transacao();
                    transacao.setIdCliente(rs.getInt("idCliente"));
                    transacao.setIdCliente(rs.getInt("idGrupo"));
                    transacao.setIdCliente(rs.getInt("idSubgrupo"));
                    transacao.setIdCliente(rs.getInt("idUsuario"));
                    transacao.setDataTransacao(rs.getString("dataTransacao"));
                    transacao.setTipoTransacao(rs.getBoolean("tipoTransacao"));
                    transacao.setValor(Double.parseDouble(String.valueOf(rs.getBigDecimal("valor"))));
                    transacao.setDataPagamento(rs.getString("dataPagamento"));
                    transacoes.add(transacao);
                }
            }
        return transacoes;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public String getUsuarioNome(int idUsuario)
    {
        String sql = "select nome from Usuario where idUsuario = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idUsuario);
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    return rs.getString("nome");
                }    
            }
            rs.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
    
    public void alterarUsuario(int idUsuario, String novaSenha)
    {
        String sql = "update Usuario set senha = ? where idUsuario = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, novaSenha);
            ps.setInt(2, idUsuario);
            ps.execute();
            ps.close();
            
            connection.close();
        } catch (Exception e) {
        }
    }
    
    public void excluirUsuario(int idUsuario) throws SQLException
    {
        String sql = "Delete from Usuario where idUsuario = ?";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idUsuario);
            ps.executeUpdate();
            connection.close();
        } catch (java.sql.SQLIntegrityConstraintViolationException e) {
            throw new SQLException("Erro ao excluir Usuario. Existem dependencias no cadastro.");
        }
    }
}
