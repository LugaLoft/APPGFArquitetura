package DAO;

import Classes.Grupo;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class GrupoDAO
{
    private Connection connection;
    ResultSet rs;
    PreparedStatement pstm;
    
    public GrupoDAO()
    {
        this.connection = new ConexaoBanco().getConexao();
    }
    
    public void cadastrarGrupo(Grupo grupo)
    {
        String sql = "insert into Grupo(nome, descricao)values(?,?)";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, grupo.getNome());
            ps.setString(2, grupo.getDescricao());
            
            ps.execute();
            ps.close();
            connection.close();
            JOptionPane.showMessageDialog(null, "Grupo cadastrado com sucesso.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar Grupo. " + e);
        }
    }
    

    public ArrayList<Grupo> getGrupos()
    {
        String sql = "select * from Grupo";
        
        ArrayList<Grupo> grupos = new ArrayList<>();
        
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    Grupo grupo = new Grupo();
                    grupo.setNome(rs.getString("nome"));
                    grupo.setDescricao(rs.getString("descricao"));
                    grupos.add(grupo);
                }
            }
        return grupos;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public String getGrupoNome(int idGrupo)
    {
        String sql = "select nome from Grupo where idgrupo = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idGrupo);
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    return rs.getString("nome");
                }    
            }
            rs.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
    
    public String getGrupoDescricao(int idSubgrupo)
    {
        String sql = "select descricao from Grupo where idgrupo = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idSubgrupo);
            try(ResultSet rs = ps.executeQuery())
            {
                while(rs.next())
                {
                    return rs.getString("descricao");
                }    
            }
            rs.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return null;
    }
    
    public void alterarGrupoNome(int idGrupo, String novoNome)
    {
        String sql = "update Grupo set nome = ? where idGrupo = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, novoNome);
            ps.setInt(2, idGrupo);
            ps.execute();
            ps.close();
            
            connection.close();
        } catch (Exception e) {
        }
    }
    
    public void alterarGrupoDescicao(int idGrupo, String novaDescricao)
    {
        String sql = "update Grupo set descricao = ? where idGrupo = ?";
        try(Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setString(1, novaDescricao);
            ps.setInt(2, idGrupo);
            ps.execute();
            ps.close();
            
            connection.close();
        } catch (Exception e) {
        }
    }
    
    public void excluirGrupo(int idGrupo) throws SQLException
    {
        String sql = "Delete from grupo where idgrupo = ?";
        
        try (Connection connection = new ConexaoBanco().getConexao();
                PreparedStatement ps = connection.prepareStatement(sql))
        {
            ps.setInt(1, idGrupo);
            ps.executeUpdate();
            connection.close();
        } catch (java.sql.SQLIntegrityConstraintViolationException e) {
            throw new SQLException("Erro ao excluir grupo. Existem dependencias no cadastro.");
        }
    }
}
