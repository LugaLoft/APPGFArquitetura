package Telas;

public class TelaPrincipal extends javax.swing.JFrame
{

    public TelaPrincipal()
    {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Aplicativo Fiscal - GF Arquitetura");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jmbMenu = new javax.swing.JMenuBar();
        jmCadastrar = new javax.swing.JMenu();
        jmiCadastrarCliente = new javax.swing.JMenuItem();
        jmiCadastrarGrupo = new javax.swing.JMenuItem();
        jmiCadastrarSubgrupo = new javax.swing.JMenuItem();
        jmAlterar = new javax.swing.JMenu();
        jmiAlterarCliente = new javax.swing.JMenuItem();
        jmiAlterarGrupo = new javax.swing.JMenuItem();
        jmiAlterarSubgrupo = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jmbMenu.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N

        jmCadastrar.setText("Cadastrar");
        jmCadastrar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jmiCadastrarCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarCliente.setText("Cliente");
        jmCadastrar.add(jmiCadastrarCliente);

        jmiCadastrarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarGrupo.setText("Grupo");
        jmCadastrar.add(jmiCadastrarGrupo);

        jmiCadastrarSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiCadastrarSubgrupo.setText("SubGrupo");
        jmCadastrar.add(jmiCadastrarSubgrupo);

        jmbMenu.add(jmCadastrar);

        jmAlterar.setText("Alterar");
        jmAlterar.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        jmiAlterarCliente.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarCliente.setText("Cliente");
        jmAlterar.add(jmiAlterarCliente);

        jmiAlterarGrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarGrupo.setText("Grupo");
        jmAlterar.add(jmiAlterarGrupo);

        jmiAlterarSubgrupo.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        jmiAlterarSubgrupo.setText("SubGrupo");
        jmAlterar.add(jmiAlterarSubgrupo);

        jmbMenu.add(jmAlterar);

        setJMenuBar(jmbMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 845, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run() {
                new TelaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu jmAlterar;
    private javax.swing.JMenu jmCadastrar;
    private javax.swing.JMenuBar jmbMenu;
    private javax.swing.JMenuItem jmiAlterarCliente;
    private javax.swing.JMenuItem jmiAlterarGrupo;
    private javax.swing.JMenuItem jmiAlterarSubgrupo;
    private javax.swing.JMenuItem jmiCadastrarCliente;
    private javax.swing.JMenuItem jmiCadastrarGrupo;
    private javax.swing.JMenuItem jmiCadastrarSubgrupo;
    // End of variables declaration//GEN-END:variables
}
