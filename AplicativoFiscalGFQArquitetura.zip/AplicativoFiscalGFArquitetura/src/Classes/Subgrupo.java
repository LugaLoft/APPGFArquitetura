package Classes;

public class Subgrupo
{
    private Integer idSubgrupo;
    private String nome;
    private String descricao;

    public Subgrupo()
    {
    }

    public Subgrupo(Integer idSubgrupo, String nome, String descricao)
    {
        this.idSubgrupo = idSubgrupo;
        this.nome = nome;
        this.descricao = descricao;
    }

    public Integer getIdSubgrupo()
    {
        return idSubgrupo;
    }

    public void setIdSubgrupo(Integer idSubgrupo)
    {
        this.idSubgrupo = idSubgrupo;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getDescricao()
    {
        return descricao;
    }

    public void setDescricao(String descricao)
    {
        this.descricao = descricao;
    }
    
        
}